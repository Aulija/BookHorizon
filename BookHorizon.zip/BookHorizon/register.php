<?php
session_start();
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $nickname = $_POST['nickname'];
    $country = $_POST['country'];

    // Hash password untuk keamanan
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // SQL untuk memasukkan data pengguna baru
    $sql = "INSERT INTO login (email, password, first_name, last_name, nickname, country) 
            VALUES (:email, :password, :first_name, :last_name, :nickname, :country)";
    $stmt = $pdo->prepare($sql);

    // Binding parameter
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':password', $hashed_password);
    $stmt->bindParam(':first_name', $first_name);
    $stmt->bindParam(':last_name', $last_name);
    $stmt->bindParam(':nickname', $nickname);
    $stmt->bindParam(':country', $country);

    // Eksekusi dan cek keberhasilan
    if ($stmt->execute()) {
        // Redirect ke halaman login setelah registrasi berhasil
        header("Location: login.php");
        exit();
    } else {
        echo "Terjadi kesalahan saat registrasi.";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account</title>
    <link rel="stylesheet" href="register.css">
</head>
<body>
    <div class="register-container">
        <div class="logo-container">
            <img src="assets/logo.png" alt="Logo">
        </div>
        <h2>Create Account</h2>
        <form class="register-form" method="POST" action="register.php">
    <select id="country" name="country">
        <option value="Indonesia">Indonesia</option>
        <option value="United States">United States</option>
        <option value="Zimbabwe">Zimbabwe</option>
    </select>
    
    <input type="email" name="email" placeholder="Email Address" required>
    <input type="text" name="first_name" placeholder="First Name" required>
    <input type="text" name="last_name" placeholder="Last Name" required>
    <input type="text" name="nickname" placeholder="Nickname">
    
    <div class="password-container">
        <input type="password" name="password" placeholder="Password" required>
        <button type="button" class="toggle-password">👁</button>
    </div>

    <div class="terms">
        <input type="checkbox" id="terms" required>
        <label for="terms">I have read and agree to the <a href="#">terms of service</a></label>
    </div>

    <button class="btn-sign-up" type="submit">Sign Up</button>
</form>

        <p>Already have an account? <a href="#">Sign In</a></p>
        <p><a href="#">Privacy Policy</a></p>
    </div>
</body>
</html>

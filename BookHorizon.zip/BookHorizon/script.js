// Mengubah konten slideshow setiap detik
let slideIndex = 0;
const slides = document.querySelectorAll('.slide');
const changeSlide = () => {
    slides.forEach((slide, index) => {
        slide.style.display = (index === slideIndex) ? 'block' : 'none';
    });
    slideIndex = (slideIndex + 1) % slides.length;
}
setInterval(changeSlide, 3000);

// Sticky navbar ketika scroll
window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.classList.add('sticky');
    } else {
        navbar.classList.remove('sticky');
    }
});

// Function untuk menampilkan snackbar
function showSnackbar(message) {
    const snackbar = document.getElementById('snackbar');
    snackbar.textContent = message; // Set custom message
    snackbar.className = 'show';  // Menambahkan "show" class agar pesan terlihat
    setTimeout(() => {
        snackbar.className = snackbar.className.replace('show', ''); // Setelah 3 detik, menyembunyikan snackbar
    }, 3000);
}

// Menambahkan event listener ke buy buttons dengan snackbar integration
const buyButtons = document.querySelectorAll('.buy-button');
buyButtons.forEach(button => {
    button.addEventListener('click', () => {
        showSnackbar('Anda harus login terlebih dahulu'); // Menampilkan snackbar dengan static message
    });
});

// Menambahkan event listener untuk search button dan menampilkan snackbar dengan hasil pencarian
const searchButton = document.getElementById('search-button');
const searchBar = document.getElementById('search-bar');
searchButton.addEventListener('click', () => {
    const searchQuery = searchBar.value;
    showSnackbar(`You searched for: ${searchQuery}`); // Tampilkan snackbar dengan hasil pencarian
});

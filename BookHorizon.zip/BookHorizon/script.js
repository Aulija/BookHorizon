// Mengubah konten slideshow setiap detik
let slideIndex = 0;
const slides = document.querySelectorAll('.slide');
const changeSlide = () => {
    slides.forEach((slide, index) => {
        slide.style.display = (index === slideIndex) ? 'block' : 'none';
    });
    slideIndex = (slideIndex + 1) % slides.length;
}
setInterval(changeSlide, 3000);

// Sticky navbar ketika scroll
window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    const scrollPosition = window.scrollY;
    const documentHeight = document.documentElement.scrollHeight;
    const windowHeight = window.innerHeight;

    const halfPageScroll = (documentHeight - windowHeight) / 2;

    if (scrollPosition === 0) {
        navbar.classList.remove('hidden');
        navbar.classList.remove('sticky');
    } else if (scrollPosition > 0 && scrollPosition < halfPageScroll) {
        navbar.classList.add('hidden');
    } else if (scrollPosition >= halfPageScroll) {
        navbar.classList.remove('hidden');
        navbar.classList.add('sticky');
    } 
});

// Mengecek status login di LocalStorage
function checkLoginStatus() {
    return localStorage.getItem('isLoggedIn') === 'true';
}

// Menyimpan status login ke LocalStorage
function setLoginStatus(status) {
    localStorage.setItem('isLoggedIn', status);
}

// Function untuk menampilkan snackbar
function showSnackbar(message) {
    const snackbar = document.getElementById('snackbar');
    snackbar.textContent = message; 
    snackbar.className = 'show';  
    setTimeout(() => {
        snackbar.className = snackbar.className.replace('show', ''); 
    }, 3000);
}

// Fungsi untuk menyimpan item ke Local Storage dengan Promise
function saveToLocalStorage(key, value) {
    return new Promise((resolve, reject) => {
        try {
            const cart = JSON.parse(localStorage.getItem(key)) || [];
            if (!cart.includes(value)) {
                cart.push(value);
                localStorage.setItem(key, JSON.stringify(cart)); 
            }
            resolve('Item berhasil ditambahkan ke keranjang');
        } catch (error) {
            reject('Gagal menambahkan item ke keranjang');
        }
    });
}

// Menambahkan event listener ke buy buttons
const buyButtons = document.querySelectorAll('.buy-button');
buyButtons.forEach(button => {
    button.addEventListener('click', () => {
        const bookTitle = button.getAttribute('data-book');
        const bookPrice = button.nextElementSibling.nextElementSibling.innerText; 
        
        if (checkLoginStatus()) {
            bukaPopupBox(bookTitle, bookPrice); 
        } else {
            showSnackbar('Anda harus login terlebih dahulu'); 
        }
    });
});

// Simulasi login (untuk contoh)
document.querySelector('.sign-in-btn').addEventListener('click', () => {
    setLoginStatus(true); 
    showSnackbar('Anda berhasil login');
});

// Menghapus semua item dari Local Storage
function clearLocalStorage() {
    localStorage.clear();
    console.log('Seluruh Local Storage telah dihapus.');
}

// Event listener untuk tombol hapus semua data
document.getElementById('clear-storage-btn').addEventListener('click', () => {
    const confirmation = confirm('Apakah Anda yakin ingin menghapus seluruh data di Local Storage?');
    if (confirmation) {
        clearLocalStorage();
    }
});

// Fungsi untuk membuka pop-up box
function bukaPopupBox(productName, price) {
    const popupBox = document.getElementById('popupBox');
    const productNameElement = document.getElementById('popup-product-name');
    const priceElement = document.getElementById('popup-price');

    productNameElement.textContent = productName;
    priceElement.textContent = price;

    popupBox.style.display = 'flex'; 
}

// Fungsi untuk menutup pop-up box
function tutupPopupBox() {
    document.getElementById('popupBox').style.display = 'none';
}

function lakukanPembayaran() {
    if (!checkLoginStatus()) { 
        showSnackbar('Anda harus login terlebih dahulu'); 
        return; 
    }

    const nama = document.getElementById("buyer-name").value;
    const nomorhp = document.getElementById("buyer-phone").value;
    const metodePembayaran = document.getElementById("payment-method").value;
    const productName = document.getElementById("popup-product-name").innerText;
    const productPrice = document.getElementById("popup-price").innerText;

    if (!nama || !nomorhp) {
        alert("Nama dan Nomor HP harus diisi!");
        return; 
    }

    const pembayaranData = {
        productName,
        productPrice,
        nama,
        nomorhp,
        metodePembayaran
    };

    localStorage.setItem('pembayaranData', JSON.stringify(pembayaranData));
    alert("Pembayaran berhasil! Terima kasih telah membeli " + productName);
    tutupPopupBox();
}

// Fungsi untuk mengambil data buku dari server
async function fetchBooks() {
    try {
        const response = await fetch('books.json'); // Ganti dengan URL API Anda
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const books = await response.json();
        return books;
    } catch (error) {
        console.error('Terjadi kesalahan saat mengambil data:', error);
    }
}

// Memanggil fetchBooks dan menampilkan data buku
async function displayBooks() {
    const books = await fetchBooks();
    if (books) {
        const booksContainer = document.getElementById('books-container'); // ID elemen yang ada di HTML
        books.forEach(book => {
            const bookElement = document.createElement('div');
            bookElement.className = 'book';
            bookElement.innerHTML = `
                <img src="${book.image}" alt="${book.title}">
                <h3>${book.title}</h3>
                <p>${book.author}</p>
                <p>Rp ${book.price.toLocaleString()}</p>
                <button class="buy-button" data-book="${book.title}" data-price="${book.price}" onclick="bukaPopupBox('${book.title}', '${book.price}')">Buy</button>
            `;
            booksContainer.appendChild(bookElement);
        });
    }
}

// Memanggil fungsi displayBooks saat halaman dimuat
window.onload = () => {
    displayBooks();
};


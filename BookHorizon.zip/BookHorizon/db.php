<?php
// Konfigurasi database
$host = 'localhost';          
$dbname = 'db_bookhorizon';     
$username = 'root';            
$password = '';                

try {
    // Membuat koneksi menggunakan PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);

    // Mengatur mode error PDO menjadi Exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Uncomment jika ingin menampilkan pesan sukses koneksi
    // echo "Koneksi berhasil";
} catch (PDOException $e) {
    // Jika koneksi gagal, tampilkan pesan error
    die("Koneksi ke database gagal: " . $e->getMessage());
}
?>

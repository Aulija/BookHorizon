<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BookHorizon Transactions</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Navbar -->
    <header>
        <nav class="navbar">
            <!-- Icon Burger -->
            <div class="burger">
                <img src="assets/burger.png" alt="Menu" class="burger-icon">
            </div>
            <div class="logo">
                <img src="assets/logo.png" alt="Logo">
                <h1>BookHorizon</h1>
            </div>

            <!-- Search Bar -->
            <div class="midsec">
                <a href="#" class="category-link">Category</a>
                <input type="text" placeholder="Search...">
                <button class="search-icon"><img src="assets/search.png" alt="Search"></button>
                <img src="assets/cart.png" alt="Cart" class="cart-icon">
            </div>

            <!-- Cart Icon and Links -->
            <div class="right-menu">
                <a href="login.php" class="sign-in-btn">Sign In</a>
                <a href="#" class="sign-up-btn">Sign Up</a>
            </div>
        </nav>
    </header>

    <!-- Transaction Table Section -->
    <section class="transaction-section">
        <h2>Transactions</h2>
        <table class="transaction-table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>27-12-2024</td>
                    <td>Auliya Putra Darmawan</td>
                    <td>Fiction</td>
                    <td>450,000</td>
                    <td><span class="status-success">Success</span></td>
                    <td><button class="detail-btn">Detail</button></td>
                </tr>
            </tbody>
        </table>
    </section>
</body>
</html>

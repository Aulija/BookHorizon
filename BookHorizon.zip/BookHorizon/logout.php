<?php
session_start();
session_unset(); // Menghapus semua session
session_destroy(); // Menghancurkan session
header('Location: index.php'); // Kembali ke halaman utama setelah logout
exit();
?>

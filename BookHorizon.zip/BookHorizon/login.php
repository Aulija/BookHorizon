<?php
session_start();
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nickname = $_POST['nickname'];
    $pw = $_POST['password'];

    // Query untuk mendapatkan data pengguna berdasarkan nickname
    $sql = "SELECT * FROM login WHERE nickname = :nickname";
    $login = $pdo->prepare($sql);
    $login->bindParam(':nickname', $nickname);
    $login->execute();
    $user = $login->fetch(PDO::FETCH_ASSOC);

    // Verifikasi password
    if ($user && password_verify($pw, $user['password'])) {
        // Set session untuk nickname
        $_SESSION['nickname'] = $nickname;

        // Redirect ke halaman utama (index.php) setelah login berhasil
        header('Location: index.php');
        exit();
    } else {
        echo "<script>alert('Nickname atau password salah.');</script>";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="login-container">
        <div class="logo-container">
            <img src="assets/logo.png" alt="Logo">
        </div>
        <h2>Sign In</h2>
        <!-- Tambahkan action="login.php" dan method="POST" -->
        <form class="login-form" action="login.php" method="POST">
            <input type="text" name="nickname" placeholder="Nickname" required>
            <div class="password-container">
                <input type="password" name="password" placeholder="Password" required>
                <button type="button" class="toggle-password">👁️</button>
        </div>
        <button type="submit" class="btn-sign-in">SIGN IN</button>
</form>

        <p class="ors">or sign in with</p>
        <div class="social-login">
            <button><img src="assets/google.png" alt="Google"></button>
            <button><img src="assets/facebook.png" alt="Facebook"></button>
            <button><img src="assets/apple.png" alt="Apple"></button>
            <button><img src="assets/tiktok.png" alt="Tiktok"></button>
            <button><img src="assets/microsoft.png" alt="Microsoft"></button>
            <button><img src="assets/twitter.png" alt="Twitter"></button>
        </div>
        <p>Don't have an account? <a href="#">Create account</a> or sign in later</p>
    </div>
</body>
</html>

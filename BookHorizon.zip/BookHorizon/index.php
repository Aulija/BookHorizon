<?php
session_start();

if (!isset($_SESSION['nickname'])) {
    // Pengguna belum login, tampilkan tombol sign-in
    $isLoggedIn = false;
} else {
    // Pengguna sudah login, tampilkan nickname dan tombol sign-out
    $isLoggedIn = true;
}

// Membaca data buku dari file JSON
$booksData = json_decode(file_get_contents('books.json'), true);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Horizon</title>
    <link rel="stylesheet" href="styles.css">
    <script defer src="script.js"></script>
</head>
<body>
    <!-- Navbar -->
    <header>
        <nav class="navbar">
            <!-- Icon Burger -->
            <div class="burger">
                <img src="assets/burger.png" alt="Menu" class="burger-icon" id="burger-icon">
            </div>

            <div class="logo">
                <img src="assets/logo.png" alt="Logo">
                <h1>BookHorizon</h1>
            </div>

            <!-- Search Bar -->
            <div class="midsec">
                <a href="#" class="category-link">Category</a>
                <input type="text" placeholder="Search..." id="search-bar">
                <button class="search-icon"><img src="assets/search.png" alt="Search" id="search-button"></button>
                <img src="assets/cart.png" alt="Cart" class="cart-icon" id="cart-icon">
            </div>

            <!-- Cart Icon and Links -->
            <div class="right-menu">
                <?php if ($isLoggedIn): ?>
                    <span class="user-nickname"><?= htmlspecialchars($_SESSION['nickname']) ?></span>
                    <a href="logout.php" class="sign-out-btn">Sign-Out</a>
                <?php else: ?>
                    <a href="login.php" class="sign-in-btn">Sign-In</a>
                    <a href="register.php" class="sign-up-btn">Sign-Up</a>
                <?php endif; ?>
            </div>
        </nav>
    </header>

       <!-- Slideshow Section -->
       <section class="slideshow">
        <div class="slideshow-container">
             <!-- Navigation buttons -->
            <a class="prev" onclick="changeSlide(-1)">&#10094;</a>
            <!-- Main Slideshow Image -->
            <div class="slide" id="slide-1">
                <img src="assets/slide1.jpg" alt="Slide 1" style="width: 100%; height: 100%; object-fit: cover; border-radius: 20px;">
            </div>
            <!-- Slide 2 -->
            <div class="slide">
                <img src="assets/slide2.jpg" alt="Slide 2" style="width: 100%; height: 100%; object-fit: cover; border-radius: 20px;">
            </div>
            <!-- Slide 3 -->
            <div class="slide">
                <img src="assets/slide3.jpg" alt="Slide 3" style="width: 100%; height: 100%; object-fit: cover; border-radius: 20px;">
            </div>  

            <!-- Navigation buttons -->
            <a class="next" onclick="changeSlide(1)">&#10095;</a>
        </div>
            <!-- Additional Photos -->
            <section class="photos">
                <div class="photo" style="background-image: url('assets/porsche.jpg');"></div>
                <div class="photo" style="background-image: url('assets/slide1.jpg');"></div>
            </section>
    </section>

    <!-- Best Selling Books Section -->
    <section class="best-sellers">
        <h2>Best Selling Books Ever</h2>
        <div class="book-container" id="books-container">
            <!-- Buku akan dimuat di sini menggunakan JavaScript -->
        </div>
    </section>

    <!-- Popup Box -->
    <!-- Popup content here -->

    <script>
        // Data buku dari PHP
        const books = <?php echo json_encode($booksData); ?>;

        // Menampilkan buku-buku di bagian best-sellers
        const booksContainer = document.getElementById('books-container');

        books.forEach(book => {
            const bookElement = document.createElement('div');
            bookElement.classList.add('book');
            bookElement.innerHTML = `
                <img src="${book.image}" alt="${book.title}" class="book-image">
                <h3>${book.title}</h3>
                <p>by ${book.author}</p>
                <p>Rp ${book.price}</p>
                <button class="view-details-btn" onclick="showPopup('${book.title}', ${book.price}, '${book.image}')">View Details</button>
            `;
            booksContainer.appendChild(bookElement);
        });

        // Function to display popup box with product details
        function showPopup(title, price, image) {
            document.getElementById('popup-product-name').innerText = title;
            document.getElementById('popup-price').innerText = price;
            document.getElementById('popupBox').style.display = 'block';
        }

        // Function to close the popup box
        function tutupPopupBox() {
            document.getElementById('popupBox').style.display = 'none';
        }
    </script>

    <!-- Snack Bar -->
    <div id="snackbar">Anda harus login</div>

    <!-- Tombol untuk menghapus Local Storage -->
    <button id="clear-storage-btn">Hapus Semua Data di Local Storage</button>
</body>
</html>
